import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newpolicy',
  templateUrl: './newpolicy.component.html',
  styleUrls: ['./newpolicy.component.css']
})
export class NewpolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

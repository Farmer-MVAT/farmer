import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerbidder',
  templateUrl: './registerbidder.component.html',
  styleUrls: ['./registerbidder.component.css']
})
export class RegisterbidderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardfarmer',
  templateUrl: './dashboardfarmer.component.html',
  styleUrls: ['./dashboardfarmer.component.css']
})
export class DashboardfarmerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

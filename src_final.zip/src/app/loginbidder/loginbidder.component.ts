import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginbidder',
  templateUrl: './loginbidder.component.html',
  styleUrls: ['./loginbidder.component.css']
})
export class LoginbidderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

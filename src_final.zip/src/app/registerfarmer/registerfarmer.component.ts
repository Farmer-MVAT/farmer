import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerfarmer',
  templateUrl: './registerfarmer.component.html',
  styleUrls: ['./registerfarmer.component.css']
})
export class RegisterfarmerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

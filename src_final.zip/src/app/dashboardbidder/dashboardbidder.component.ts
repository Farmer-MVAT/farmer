import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardbidder',
  templateUrl: './dashboardbidder.component.html',
  styleUrls: ['./dashboardbidder.component.css']
})
export class DashboardbidderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginfarmer',
  templateUrl: './loginfarmer.component.html',
  styleUrls: ['./loginfarmer.component.css']
})
export class LoginfarmerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginadmin',
  templateUrl: './loginadmin.component.html',
  styleUrls: ['./loginadmin.component.css']
})
export class LoginadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

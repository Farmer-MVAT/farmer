import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claimpolicy',
  templateUrl: './claimpolicy.component.html',
  styleUrls: ['./claimpolicy.component.css']
})
export class ClaimpolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewmarketplace',
  templateUrl: './viewmarketplace.component.html',
  styleUrls: ['./viewmarketplace.component.css']
})
export class ViewmarketplaceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placerequest',
  templateUrl: './placerequest.component.html',
  styleUrls: ['./placerequest.component.css']
})
export class PlacerequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

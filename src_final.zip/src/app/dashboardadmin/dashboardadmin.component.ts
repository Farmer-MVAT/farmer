import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardadmin',
  templateUrl: './dashboardadmin.component.html',
  styleUrls: ['./dashboardadmin.component.css']
})
export class DashboardadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

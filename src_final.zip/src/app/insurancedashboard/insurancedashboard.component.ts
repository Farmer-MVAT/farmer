import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurancedashboard',
  templateUrl: './insurancedashboard.component.html',
  styleUrls: ['./insurancedashboard.component.css']
})
export class InsurancedashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
